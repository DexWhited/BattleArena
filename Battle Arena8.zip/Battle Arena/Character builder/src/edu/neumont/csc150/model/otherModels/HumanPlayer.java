package edu.neumont.csc150.model.otherModels;

import edu.neumont.csc150.controller.Generator;
import edu.neumont.csc150.model.character.Character;
import edu.neumont.csc150.view.BattleUI;

import java.io.Console;
import java.io.IOException;


public class HumanPlayer extends Player{
    private final BattleUI ui = new BattleUI();
    public HumanPlayer(String name, Character character, String currency, String inventory) {
        super(name, character, currency, inventory);
    }

    public HumanPlayer(String name) {
        super(name);
    }

    @Override
    public void takeTurn(Character character, Character battlingCharacter) throws IOException {
        boolean quit = false;

        while (!quit) {
            ui.battleMenu();
            int selection = ui.getUserInputAsInt(1, 2);
            switch (selection) {
                case 1:
                    ui.attackMenu();
                    int userAttack = ui.getUserInputAsInt(1, 2);
                    if(userAttack == 1) {
                        //player2 hp - player1 attack
                        battlingCharacter.setHp(battlingCharacter.getHp() - character.baseAttack());
                    } else {
                        //player2 hp - player1 special attack
                        battlingCharacter.setHp(battlingCharacter.getHp() - character.specialAttack());
                    }
                    break;
                case 2:
                    ui.healMenu();
                    break;
                default:
                    throw new IllegalArgumentException("unknown number");
            }

        }
    }

}