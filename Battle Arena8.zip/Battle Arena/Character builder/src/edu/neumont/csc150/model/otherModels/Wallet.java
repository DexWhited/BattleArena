package edu.neumont.csc150.model.otherModels;

public class Wallet {
}
