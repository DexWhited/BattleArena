package edu.neumont.csc150.model.otherModels;

import edu.neumont.csc150.controller.Generator;
import edu.neumont.csc150.model.character.Character;

public class AIPlayer extends Player{
    public AIPlayer(String name, Character character, String currency, String inventory) {
        super(name, character, currency, inventory);
    }

    public AIPlayer(String name) {
        super(name);
    }

    @Override
    public void takeTurn(Character character, Character battlingCharacter) {

    }

}
