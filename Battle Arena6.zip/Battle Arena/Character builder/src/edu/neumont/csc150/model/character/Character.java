package edu.neumont.csc150.model.character;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public abstract class Character {
    protected String name;
    protected int hp;
    protected int speed;


    public Character() {}

    public String getName() {return name;}

    public void setName(String name) {
        if(name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        } else {
            this.name = name;
        }
    }

    public int getHp() {return hp;}

    public abstract void setHp();

    public int getSpeed() {return speed;}

    public abstract void setSpeed();

    public abstract void baseAttack();



    @Override
    public String toString() {
        return name + "\r\n" +
                "HP: " + hp + "\r\n" +
                "Speed: " + speed;
    }

    public String toBaseAttack() {
        return "";
    }
}
