package edu.neumont.csc150.model.character;

import edu.neumont.csc150.model.character.Character;

import java.util.concurrent.ThreadLocalRandom;

public class Cleric extends Character {
    public final int MIN_HP = 100;
    public final int MAX_HP = 169;
    public final int MIN_SPEED = 20;
    public final int MAX_SPEED = 25;
    public final int MIN_DAMAGE = 20;
    public final int MAX_DAMAGE = 25;
    private String typeOfAttack;
    private int damageDone = 0;
    private int totalHealed = 0;

    public Cleric() {}

    public Cleric(String name) {
        setName(name);
        setHp();
        setSpeed();
    }

    public String getTypeOfAttack() {
        return typeOfAttack;
    }

    public void setTypeOfAttack(String typeOfAttack) {
        this.typeOfAttack = typeOfAttack;
    }

    public int getDamageDone() {
        return damageDone;
    }

    public void setDamageDone(int damageDone) {
        this.damageDone = damageDone;
    }

    public int getTotalHealed() {
        return totalHealed;
    }

    public void setTotalHealed(int totalHealed) {
        this.totalHealed = totalHealed;
    }

    @Override
    public void setHp() {
        this.hp = ThreadLocalRandom.current().nextInt(MIN_HP, MAX_HP) + 1;
    }

    @Override
    public void setSpeed() {
        this.speed = ThreadLocalRandom.current().nextInt(MIN_SPEED, MAX_SPEED) + 1;
    }

    @Override
    public void baseAttack() {
        setDamageDone(ThreadLocalRandom.current().nextInt(MIN_DAMAGE, MAX_DAMAGE) + 1);
        setTypeOfAttack("Base Attack");
    }

    public int healingMagic() {
        int special = 37;
        setTotalHealed(totalHealed + special);
        setTypeOfAttack("Special: Healing Magic");
        return special;
    }

    @Override
    public String toString() {
        return super.toString() + "\r\n" +
                "Uses [" + typeOfAttack + "]!" + "\r\n" +
                "Attack Damage: " + damageDone + "\r\n" +
                "Total Healed: " + totalHealed;
    }
}