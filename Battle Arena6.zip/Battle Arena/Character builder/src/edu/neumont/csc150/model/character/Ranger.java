package edu.neumont.csc150.model.character;

import edu.neumont.csc150.model.character.Character;

import java.util.concurrent.ThreadLocalRandom;

public class Ranger extends Character {
    public final int MIN_HP = 100;
    public final int MAX_HP = 169;
    public final int MIN_SPEED = 20;
    public final int MAX_SPEED = 25;
    public final int MIN_DAMAGE = 20;
    public final int MAX_DAMAGE = 30;
    private String typeOfAttack;
    private int damageDone = 0;

    public Ranger() {}

    public Ranger(String name) {
        setName(name);
        setHp();
        setSpeed();
    }

    public String getTypeOfAttack() {
        return typeOfAttack;
    }

    public void setTypeOfAttack(String typeOfAttack) {
        this.typeOfAttack = typeOfAttack;
    }

    public int getDamageDone() {
        return damageDone;
    }

    public void setDamageDone(int damageDone) {
        this.damageDone = damageDone;
    }

    @Override
    public void setHp() {
        this.hp = ThreadLocalRandom.current().nextInt(MIN_HP, MAX_HP) + 1;
    }

    @Override
    public void setSpeed() {
        this.speed = ThreadLocalRandom.current().nextInt(MIN_SPEED, MAX_SPEED) + 1;
    }

    @Override
    public void baseAttack() {
        setDamageDone(ThreadLocalRandom.current().nextInt(MIN_DAMAGE, MAX_DAMAGE) + 1);
        setTypeOfAttack("Base Attack");
    }

    public int twoWeapon() {
        int special = 37;
        setDamageDone(damageDone + special);
        setTypeOfAttack("Special Attack: Two Weapons");
        return special;
    }

    @Override
    public String toString() {
        return super.toString() + "\r\n" +
                "Uses [" + typeOfAttack + "]!" + "\r\n" +
                "Attack Damage: " + damageDone;
    }
}
