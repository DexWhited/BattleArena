package edu.neumont.csc150.controller;

public class AI extends Player{
    public AI(String name, String character, String currency) {
        super(name, character, currency);
    }
}
