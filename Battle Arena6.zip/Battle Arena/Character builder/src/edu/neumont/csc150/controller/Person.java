package edu.neumont.csc150.controller;

public class Person extends Player{


    public Person(String name, String character, String currency) {
        super(name, character, currency);
    }
}
