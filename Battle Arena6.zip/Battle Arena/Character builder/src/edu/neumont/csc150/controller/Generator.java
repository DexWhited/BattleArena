package edu.neumont.csc150.controller;

import edu.neumont.csc150.model.character.Character;
import edu.neumont.csc150.model.character.*;
import edu.neumont.csc150.utils.Console;
import edu.neumont.csc150.view.BattleUI;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Generator {
    public static ArrayList<Character> charList = new ArrayList<>();
    private final BattleUI ui = new BattleUI();
    Random random = new Random();


    public void run() throws IOException {

        Player player = new Player();
        boolean completed = false;
        String selection = null;


        while (!completed) {
            if (selection == null) {
                selection = Console.getString("What is your name: ");
                player = new Player(selection);
            } else {
                completed = true;

            }
        }

        enterName(player);


    }

    private void enterName(Player player) throws IOException {

        boolean keepLooping = true;
        while (keepLooping) {
            ui.mainMenu();
            int selection = ui.getUserInputAsInt(1, 6);
            switch (selection) {
                case 1:
                    charCreate();
                    break;
                case 2:
                    charView();
                    break;
                case 3:
                    charBattle(player);
                    break;
                case 4:
                    walletView();
                    break;
                case 5:
                    viewStore();
                    break;
                case 6:
                    keepLooping = false;
                    break;
                default:
                    throw new IllegalArgumentException("unknown number");
            }
        }
    }

    private void viewStore() {

    }

    private void setStats(Character type) {
        type.setHp();
        type.setSpeed();
    }

    private void walletView() {

    }

    private Character charBattle(Player player) throws IOException {
        int i = 1;
        for (Character character1 : charList) {
            System.out.println(i + ": " + character1.getName());
            i++;
        }

        int selection = Console.getInteger("Please choose a character to bet on.");

        // this line is canceling anything below out
        //Character character = turn();
        Character character = Battle(player);
        return charList.get(selection);

/*        i = 0;
        for (Character character1:charList){
            System.out.println(i + ": " + character1.getName());
            i++;
        }
         int selection2 = Console.getInteger("Chose a character to fight");

        Character character2 = charList.get(selection2);*/

    }

    private Character Battle(Player player) throws IOException {
        int i = 1;
        for (Character character1 : charList) {
            System.out.println(i + ": " + character1.getName());
            i++;
        }

        int selection = Console.getInteger("Please choose a character to battle.");

        // this line is canceling anything below out
        Character character = turn(player);
        return charList.get(selection);

    }



    private Character turn(Player player) throws IOException {
        boolean gamePlay = true;

        ui.battleMenu(player);
        int selection = ui.getUserInputAsInt(1, 2);
            switch (selection) {
                case 1:
                  //  ui.battleMenu(player);
                    Character character = attackTurn(player);
                    break;
                case 2:
                    ui.healMenu();
                    break;
                default:
                    throw new IllegalArgumentException("unknown number");
            }


        return null;
    }

    private Character attackTurn(Player player) throws IOException {
        ui.attackMenu();
        Character character = null;
        int selection = ui.getUserInputAsInt(1, 2);
        switch (selection) {
            case 1: //regular attack'\
                character.baseAttack();
                break;
            case 2: //Strong attack
                break;
            default:
                throw new IllegalArgumentException("unknown number");
        }
        return null;
    }


    private void charView() {
        for (Character character : charList) {
            System.out.println(" My name is " + character.getName() + ". I am a " + character.getClass().getSimpleName() + ". My speed is: " + character.getSpeed() +". My attack is: " + character.toBaseAttack());
        }
    }

    private void charCreate() {
        Character character = null;
        System.out.println(" Choose a class! \r\n " +
                "\t1: Bard \r\n" +
                "\t2: Cleric \r\n" +
                "\t3: Druid \r\n" +
                "\t4: Elf \r\n" +
                "\t5: Fighter \r\n" +
                "\t6: Paladin \r\n" +
                "\t7: Ranger \r\n" +
                "\t8: Rouge \r\n" +
                "\t9: Sorcerer \r\n");
        int selection = Console.getInteger("Please enter a number", 1, 9);

        switch (selection) {
            case 1:
                Bard bard = new Bard();
                character = bard;
                setStats(bard);
                charList.add(bard);
                break;
            case 2:
                Cleric cleric  = new Cleric();
                character = cleric;
                setStats(cleric);
                charList.add(cleric);
                break;
            case 3:
                Druid druid = new Druid();
                character = druid;
                setStats(druid);
                charList.add(druid);
                break;
            case 4:
                Elf elf = new Elf();
                character = elf;
                setStats(elf);
                charList.add(elf);
                break;
            case 5:
                Fighter fighter = new Fighter();
                character = fighter;
                setStats(fighter);
                charList.add(fighter);
                break;
            case 6:
                Paladin paladin = new Paladin();
                character = paladin;
                setStats(paladin);
                charList.add(paladin);
                break;
            case 7:
                Ranger ranger = new Ranger();
                character = ranger;
                setStats(ranger);
                charList.add(ranger);
                break;
            case 8:
                Rouge rouge = new Rouge();
                character = rouge;
                setStats(rouge);
                charList.add(rouge);
                break;
            case 9:
                Sorcerer sorcerer = new Sorcerer();
                character = sorcerer;
                setStats(sorcerer);
                charList.add(sorcerer);
                break;
        }

        character.setName(Console.getString("Please enter a name"));
        System.out.println("My name is " + character.getName() + " my class is " + character.getClass().getSimpleName() + ". My hp is: " + character.getHp() + ". My speed is: " + character.getSpeed() + ". My Attack is: " + character.toBaseAttack());

    }


}
