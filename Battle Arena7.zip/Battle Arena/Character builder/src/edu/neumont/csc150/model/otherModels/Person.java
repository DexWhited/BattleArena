package edu.neumont.csc150.model.otherModels;

import edu.neumont.csc150.model.otherModels.Player;

public class Person extends Player {


    public Person(String name, String character, String currency) {
        super(name, character, currency);
    }
}
