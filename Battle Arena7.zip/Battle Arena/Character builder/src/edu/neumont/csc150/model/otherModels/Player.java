package edu.neumont.csc150.model.otherModels;

import edu.neumont.csc150.model.Potion.Potion;
import edu.neumont.csc150.model.otherModels.Wallet;

import java.util.ArrayList;

public class Player {
    private final ArrayList<Wallet> walList = new ArrayList<>();
    private final ArrayList<Potion> inventory = new ArrayList<>();
    private String name;
    private String character;
    private String currency;

    public Player() {}

    public Player(String name) {
        this.name = name;
    }

    public Player(String name, String character, String currency) {
        setName(name);
        setCharacter(character);
        setCurrency(currency);
    }

    public ArrayList<Wallet> getWalList() {
        return walList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCharacter() {
        return character;
    }

    public void setCharacter(String character) {
        this.character = character;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public ArrayList<Potion> getInventory() {
        return inventory;
    }

    public void addInventory(Potion potion) {
       inventory.add(potion);
    }

    public int inventorySize() {
        return inventory.size();
    }

//    public int takeTurn(){
//
//        int hp = character2.getHp();
//        int attack = character.baseAttack();
//
//        int battle = (hp- attack);
//
//
//        return battle;
      //  character2.getHp() - character2.baseAttack();
        }

    /*
    ----------Battle arena------------
    Turn based battle game with the ability to heal your character

    each character has a regular and strong attack.
    Strong attack can only be used once.
    player's turn is immediately followed but the computers turn.


    ---------character create------------------
    Choose name.
    choose class.
    randomly generate hp, speed, and health based on settings in class classes.
    Character is added to an array list.



    ---------battle----------
    Prompted with attack or view inventory
    if inventory is empty then display 0 potions
    attack has 2 options (strong or normal)
    turns are taken till a  character's hp = 0



    ---------betting-----------
    If your character wins,then five coins are added to your wallet
    else one coin is added





     */








