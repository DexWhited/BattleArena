package edu.neumont.csc150.model.otherModels;

public class Store {
    /*
    Basic potion: 5 coins
    Super potion: 8 coins
    Hyper potion: 14 coins
    Full heal: 30 coins
     */
}
