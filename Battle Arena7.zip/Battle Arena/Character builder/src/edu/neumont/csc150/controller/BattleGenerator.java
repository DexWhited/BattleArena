package edu.neumont.csc150.controller;

public class BattleGenerator {
}
