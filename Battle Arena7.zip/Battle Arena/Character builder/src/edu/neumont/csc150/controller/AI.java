package edu.neumont.csc150.controller;

import edu.neumont.csc150.model.otherModels.Player;

public class AI extends Player {
    public AI(String name, String character, String currency) {
        super(name, character, currency);
    }
}
