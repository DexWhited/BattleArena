package edu.neumont.csc150.model.character;

import edu.neumont.csc150.model.character.Characters;

import javax.xml.stream.events.Characters;

public class Fighter extends Characters {
    private int doubleDamage;
    private final int MAX_SPEED = 15;
    private final int MIN_SPEED = 10;
    private final int MAX_DAMAGE = 35;
    private final int MIN_DAMAGE = 22;

    public Fighter(int doubleDamage) {
        this.doubleDamage = doubleDamage;
        setHp(random.nextInt(100, 169));
        setSpeed(random.nextInt(MIN_SPEED, MAX_SPEED));
    }

    public int getDoubleDamage() {
        return doubleDamage;
    }

    public void setDoubleDamage(int doubleDamage) {
        this.doubleDamage = doubleDamage;
    }

    public int getMAX_SPEED() {
        return MAX_SPEED;
    }

    public int getMIN_SPEED() {
        return MIN_SPEED;
    }

    public int getMAX_DAMAGE() {
        return MAX_DAMAGE;
    }

    public int getMIN_DAMAGE() {
        return MIN_DAMAGE;
    }

    @Override
    protected void setHp(int hp) {

    }

    @Override
    protected void setSpeed(int speed) {

    }

    @Override
    protected int baseAttack(int rollValue) {

    }
}
