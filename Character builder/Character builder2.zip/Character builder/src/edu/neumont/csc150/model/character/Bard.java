package edu.neumont.csc150.model.character;

import java.util.concurrent.ThreadLocalRandom;

public class Bard extends Character {
    private final int MAX_HP = 30;
    private final int MIN_HP = 15;
    private final int MAX_SPEED = 10;
    private final int MIN_SPEED = 6;
    private int totalDamage;

    public Bard() {}

    public Bard(String name, int hp, int speed) {
        setName(name);
        setHp(hp);
        setSpeed(speed);
    }

    @Override
    protected void setHp(int hp) {
        this.hp = ThreadLocalRandom.current().nextInt(MIN_HP, MAX_HP) + 1;
    }

    @Override
    protected void setSpeed(int speed) {
        this.speed = ThreadLocalRandom.current().nextInt(MIN_SPEED, MAX_SPEED) + 1;
    }

    @Override
    protected int baseAttack(int rollValue) {
        return 0; //need to ask for basic attacks
    }

    public int musicDamage(int rollValue) {
        int damage = rollValue; //just for now
        return damage;
    }

    @Override
    public String toString() {
        return super.toString() + "\r\n" +
                "Total Damage: " + totalDamage;
    }
}
