package edu.neumont.csc150.model.Potion;

public class SuperPotion extends Potion{
}
