package edu.neumont.csc150.model.Potion;

public class Potion {
    public int amountHealed;
    public String name;
}
