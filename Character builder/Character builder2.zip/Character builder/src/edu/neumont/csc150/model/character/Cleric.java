package edu.neumont.csc150.model.character;

import edu.neumont.csc150.model.character.Character;

public class Cleric extends Character {
    private final int MAX_HP = ;
    private final int MIN_HP = ;
    private final int MAX_SPEED = ;
    private final int MIN_SPEED = ;
    private int healingMagic;
}
