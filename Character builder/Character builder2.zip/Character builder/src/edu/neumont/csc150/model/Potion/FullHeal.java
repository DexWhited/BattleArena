package edu.neumont.csc150.model.Potion;

public class FullHeal extends Potion{
}
