package edu.neumont.csc150.model.character;

import java.util.Random;

public abstract class Character {
    protected String name;
    protected int hp;
    protected int speed;
    private Random random = new Random();

    public Character(){};

    public Character(String name, int hp, int speed) {
        setName(name);
        setHp(hp);
        setSpeed(speed);
    }

    public String getName() {return name;}

    protected void setName(String name) {
        if(name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        } else {
            this.name = name;
        }
    }

    public int getHp() {return hp;}

    protected abstract void setHp(int hp);

    public int getSpeed() {return speed;}

    protected abstract void setSpeed(int speed);

    protected abstract int baseAttack(int rollValue);

    public int roll(int numberOfDice, int numberOfSides) {
        int damage = 0;
        for (int i = 0; i < numberOfDice; i++) {
            damage = damage + random.nextInt(1, numberOfSides);
        }
        return damage;
    }

    @Override
    public String toString() {
        return name + "\r\n" +
                "HP: " + hp + "\r\n" +
                "Speed: " + speed;
    }
}
