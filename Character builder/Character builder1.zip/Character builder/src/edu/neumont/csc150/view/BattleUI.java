package edu.neumont.csc150.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BattleUI {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    //anything interacting with the user
    //System.out.println(();
    public int getUserInputAsInt(int min, int max) throws IOException {
        int input = 0;
        do {
            String line = br.readLine();
            try {
                input = Integer.parseInt(line);
                if (input < min || input > max) {
                    throw new NumberFormatException("out of range");
                }
                break;
            } catch (NumberFormatException ex) {
                System.out.println("Input invalid. You must ender a number between " + min + " and " + max);

            }
        } while (true);


        return input;
    }



    public void mainMenu() {

        System.out.println("What would you like to do? \r\n" +
                "\t1: Create a character \r\n" +
                "\t2: Generate a random character\r\n" +
                "\t3: View characters\r\n" +
                "\t4: Engage in battle\r\n" +
                "\t5: View wallet\r\n" +
                "\t6: End simulation\r\n");

    }

    public void battleMenu(){
        System.out.println("What would you like to do? \r\n" +
                "\t1: Attack \r\n" +
                "\t2: Heal\r\n" +
                "\t3: View inventory\r\n");
    }


}
