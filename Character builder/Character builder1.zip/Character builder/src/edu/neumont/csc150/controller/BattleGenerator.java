package edu.neumont.csc150.controller;

import edu.neumont.csc150.model.character.Characters;
import edu.neumont.csc150.view.BattleUI;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class BattleGenerator {
    Random random = new Random();
    private final BattleUI ui = new BattleUI();
    private final ArrayList<Characters> zombList = new ArrayList<>();

    public void run() throws IOException {
        boolean keepLooping = true;
        while (keepLooping) {
            ui.mainMenu();
            int selection = ui.getUserInputAsInt(1, 6);
            switch (selection) {
                case 1:
                    charCreate();
                    break;
                case 2:
                    randomChar();
                    break;
                case 3:
                    charView();
                    break;
                case 4:
                    charBattle();
                    break;
                case 5:
                    walletView();
                    break;
                case 6:
                    keepLooping = false;
                    break;
                default:
                    throw new IllegalArgumentException("unknown number");
            }

        }

    }

    private void walletView() {
    }

    private void charBattle() {
    }

    private void charView() {
    }

    private void randomChar() {
    }

    private void charCreate() {
    }

}
