package edu.neumont.csc150.model.character;

public abstract class Characters {
    protected String name;
    protected int hp;
    protected int speed;

    public Characters(){};

    public Characters(String name, int hp, int speed) {
        setName(name);
        setHp(hp);
        setSpeed(speed);
    }

    public String getName() {return name;}

    protected void setName(String name) {
        if(name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        } else {
            this.name = name;
        }
    }

    public int getHp() {return hp;}

    protected abstract void setHp(int hp);

    public int getSpeed() {return speed;}

    protected abstract void setSpeed(int speed);

    protected abstract int baseAttack(int rollValue);

    @Override
    public String toString() {
        return "Name: " + name +
                " HP: " + hp +
                " Speed: " + speed;
    }
}
