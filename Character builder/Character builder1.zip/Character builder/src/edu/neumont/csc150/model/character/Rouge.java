package edu.neumont.csc150.model.character;

import edu.neumont.csc150.model.character.Characters;

public class Rouge extends Characters {
    private final int MAX_HP = 30;
    private final int MIN_HP = 15;
    private final int MAX_SPEED = 10;
    private final int MIN_SPEED = 6;
}
